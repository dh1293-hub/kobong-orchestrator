from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Dict, Any
from datetime import datetime, timezone
import json, uuid, os, socket, threading, re

def _now():
    return datetime.now(timezone.utc).astimezone()

def _tz_id() -> str:
    return os.getenv("APP_TZ") or os.getenv("TZ") or "Asia/Seoul"

def _app_obj(name_fallback: str, module: Optional[str]) -> Dict[str, Optional[str]]:
    name = module if module is not None else (name_fallback or "kobong-orchestrator")
    ver = os.getenv("APP_VER") or os.getenv("APP_VERSION") or "0.0.0"
    commit = os.getenv("APP_COMMIT") or os.getenv("GIT_COMMIT") or None
    return {"name": name, "ver": ver, "commit": commit}

_STATUS_TO_CODE = {"ok":0,"retry":1,"timeout":2,"assert_fail":3,"cancel":4,"fatal":9}
_CODE_TO_STATUS = {v:k for k,v in _STATUS_TO_CODE.items()}

def _result_obj(result_status: Optional[str], result_code: Optional[int], fallback_ok: bool = True) -> Dict[str, Any]:
    status = (result_status or "").strip().lower() if result_status else None
    code = int(result_code) if result_code is not None else None
    if status and code is None: code = _STATUS_TO_CODE.get(status, 9)
    if code is not None and not status: status = _CODE_TO_STATUS.get(int(code), "fatal")
    if status is None and code is None:
        status = "ok" if fallback_ok else "fatal"
        code = _STATUS_TO_CODE[status]
    return {"status": status, "code": int(code)}

_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", re.IGNORECASE)
_SECRET_KV_RE = re.compile(r"(?i)\b(api[_-]?key|apikey|token|secret|password)\b\s*([:=])\s*([^\s,;]+)")
_LONG_TOKEN_RE = re.compile(r"\b[A-Za-z0-9][A-Za-z0-9\-_]{16,}\b")

def _scrub(text: Optional[str]) -> Optional[str]:
    if not text: return text
    t = _EMAIL_RE.sub("[MASKED_EMAIL]", text)
    t = _SECRET_KV_RE.sub(lambda m: f"{m.group(1)}{m.group(2)}[MASKED_TOKEN]", t)
    t = _LONG_TOKEN_RE.sub("[MASKED_TOKEN]", t)
    return t

def _action_obj(step: Optional[int], dsl_id: Optional[str]) -> Dict[str, Optional[str]]:
    try: s = int(step) if step is not None else 0
    except Exception: s = 0
    return {"step": s, "dsl_id": dsl_id}

@dataclass
class JsonLogger:
    app: str = "kobong-orchestrator"
    env: Optional[str] = None

    def make_record(
        self, level: str = "INFO", action: str = "contract-test", message: str = "",
        *, module: Optional[str] = None, action_step: Optional[int] = None, dsl_id: Optional[str] = None,
        result_status: Optional[str] = None, result_code: Optional[int] = None,
        duration_ms: Optional[int] = None, latency_ms: Optional[int] = None,
        env: Optional[str] = None, trace_id: Optional[str] = None,
        extra: Optional[Dict[str, Any]] = None, **kwargs,
    ) -> Dict[str, Any]:
        dt = _now()
        rec: Dict[str, Any] = {
            "timestamp": dt.isoformat(),
            "tz": _tz_id(),
            "level": str(level).upper(),
            "app": _app_obj(self.app, module),
            "env": env if env is not None else (self.env or os.getenv("APP_ENV") or os.getenv("ENV") or os.getenv("NODE_ENV") or "local"),
            "host": socket.gethostname(),
            "pid": os.getpid(),
            "thread": threading.current_thread().name,
            "trace_id": trace_id or str(uuid.uuid4()),
            "action": _action_obj(action_step if action_step is not None else kwargs.get("step"), kwargs.get("dsl_id") if dsl_id is None else dsl_id),
            "result": _result_obj(result_status, result_code),
            "latency_ms": int(latency_ms if latency_ms is not None else (duration_ms if duration_ms is not None else 0)),
            "message": _scrub(message),
        }
        if extra:
            for k, v in extra.items():
                if isinstance(v, str):
                    rec[k] = _scrub(v)
                elif k not in ("app","action","result"):
                    rec[k] = v
        for k, v in kwargs.items():
            if k not in rec and k not in ("app","action","result"):
                rec[k] = _scrub(v) if isinstance(v, str) else v
        return rec

    def log(self, message: str = "", level: str = "INFO", action: str = "contract-test", **kwargs):
        return self.make_record(level=level, action=action, message=message, **kwargs)

    def record(self, *args, **kwargs): return self.make_record(*args, **kwargs)
    def create(self, *args, **kwargs): return self.make_record(*args, **kwargs)
    def to_json(self, **kwargs) -> str:
        return json.dumps(self.make_record(**kwargs), ensure_ascii=False)
