(()=>{ if(window.__tl_wiring_v2){return;} window.__tl_wiring_v2=1;
if(!window.__TL_API){ console.log("[timeline-wiring] awaiting tools v2"); }
})();